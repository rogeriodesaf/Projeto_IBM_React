import Navbar from './components/Navbar'
import ProductList from './components/ProductList'
import Cart from './components/Cart'
import { Routes, Route, Link } from 'react-router-dom'

function Home() {
  return (
    <div className="container">
      <h1>Bem-vindo à Paradise Nursery</h1>
      <p className="muted">Sua loja de plantas de interior. Clique abaixo para ver nossas plantas.</p>
      <Link to="/products"><button className="btn">Ver produtos</button></Link>
    </div>
  )
}

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<ProductList />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
      <footer>© {new Date().getFullYear()} Paradise Nursery</footer>
    </>
  )
}
