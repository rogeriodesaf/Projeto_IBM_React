export const SECTIONS = [
  { id: 'aromaticas', title: 'Plantas Aromáticas' },
  { id: 'medicinais', title: 'Plantas Medicinais' },
  { id: 'sombra', title: 'Plantas de Sombra' },
]

export const PLANTS = [
  { id: 'lavanda', name: 'Lavanda', price: 39.9, section: 'aromaticas',
    image: 'https://images.unsplash.com/photo-1598899134739-24b9c6b3f1e9?q=80&w=800&auto=format&fit=crop' ,
    description: 'Aromática, ótima para ambientes relaxantes.'
  },
  { id: 'hortela', name: 'Hortelã', price: 19.9, section: 'aromaticas',
    image: 'https://images.unsplash.com/photo-1615486364052-0f34f4f8f6dd?q=80&w=800&auto=format&fit=crop',
    description: 'Fácil de cuidar, cresce rápido.'
  },
  { id: 'babosa', name: 'Babosa (Aloe Vera)', price: 29.9, section: 'medicinais',
    image: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=800&auto=format&fit=crop',
    description: 'Folhas suculentas com diversas utilidades.'
  },
  { id: 'erva-cidreira', name: 'Erva-cidreira', price: 24.9, section: 'medicinais',
    image: 'https://images.unsplash.com/photo-1466786784937-3e682c802b14?q=80&w=800&auto=format&fit=crop',
    description: 'Chás deliciosos e calmantes.'
  },
  { id: 'zamioculca', name: 'Zamioculca', price: 79.9, section: 'sombra',
    image: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=800&auto=format&fit=crop',
    description: 'Resistente e perfeita para ambientes internos.'
  },
  { id: 'jiboia', name: 'Jibóia', price: 49.9, section: 'sombra',
    image: 'https://images.unsplash.com/photo-1614594859867-8f3bd2e2a8aa?q=80&w=800&auto=format&fit=crop',
    description: 'Trepadeira com folhas verdes vibrantes.'
  },
]
